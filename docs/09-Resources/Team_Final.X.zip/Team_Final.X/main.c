#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/adc/adc.h"
#include "mcc_generated_files/pwm/pwm3_16bit.h"
#include <stdio.h>

#define ADC_MAX           4095u       // 12-bit ADC
#define VREF              5.0f        // ADC reference voltage in volts

// Effective op-amp gain from LM35 to PIC input
// (based on R1=1k, R2=10k, R3=10k, R4=5k and your measured values)
#define OPAMP_GAIN        23.3f       // Vout ~= OPAMP_GAIN * V_LM35

// LM35 threshold: 30 �C ? 86 �F
#define TEMP_THRESHOLD_F  86.0f       // temperature threshold in Fahrenheit

#define PWM_MAX           65535u      // 16-bit PWM max duty cycle

void main(void)
{
    SYSTEM_Initialize();

    uint16_t adcValue      = 0;
    float    voltage       = 0.0f;    // op-amp output (what the ADC sees)
    float    sensorVolt    = 0.0f;    // actual LM35 voltage (after dividing by gain)
    float    temperatureC  = 0.0f;
    float    temperatureF  = 0.0f;
    uint16_t ledDuty       = 0;
    bool     buttonPressed = false;

    while (1)
    {
        // ----- ADC READ -----
        // Read ADC channel connected to LM35/op-amp output
        ADC_ChannelSelect(ADC_CHANNEL_ANA0);  // change if input pin differs
        ADC_ConversionStart();
        while (!ADC_IsConversionDone());
        adcValue = ADC_ConversionResultGet();

        // Debug: print raw ADC reading
        printf("Raw ADC value: %u\r\n", adcValue);

        // ----- VOLTAGE AT PIC PIN (OP-AMP OUTPUT) -----
        voltage = ((float)adcValue / (float)ADC_MAX) * VREF;
        printf("Calculated voltage (op-amp out): %.3f V\r\n", voltage);

        // ----- COMPENSATE FOR OP-AMP GAIN -----
        // LM35 voltage at its pin
        sensorVolt = voltage / OPAMP_GAIN;

        // ----- LM35: VOLTAGE ? �C ? �F -----
        // LM35 gives 10 mV per �C  =>  0.01 V per �C, 0 �C at 0 V
        //temperatureC = sensorVolt * 100.0f;                 // �C
        temperatureF = (adcValue/ 3.5f ); // �F

        // Print in Fahrenheit
        printf("Calculated temperature: %.2f�F\r\n", temperatureF);
        

        // ----- BUTTON (active low on RB1, adjust if needed) -----
        buttonPressed = (PORTBbits.RB1 == 0);

        // ----- LED BRIGHTNESS LOGIC -----
        // Base LED brightness: dim to show board running
        ledDuty = PWM_MAX / 16;

        // Brighten LED if temperature exceeds threshold (comparison in �F)
        if (temperatureF > TEMP_THRESHOLD_F)
        {
            ledDuty = PWM_MAX / 2;
        }

        // Full LED brightness on debug button press
        if (buttonPressed)
        {
            ledDuty = PWM_MAX;
        }

        // Apply PWM duty to LED
        PWM3_16BIT_SetSlice1Output1DutyCycleRegister(ledDuty);
        PWM3_16BIT_LoadBufferRegisters();

        __delay_ms(1000);  // slow down debug prints
    }
}
